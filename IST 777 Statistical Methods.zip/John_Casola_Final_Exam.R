#John Casola IST 777 Week 11 Final Exam
getwd()
setwd("C:/Users/johnc/Documents/IST 777/Final")
library(tseries)

#load the data
load("~/IST 777/Final/allSchoolsReportStatus[3].RData")
load("~/IST 777/Final/reportSample3.RData")
load("~/IST 777/Final/usVaccines[3].RData")
#create copies of data
school <- allSchoolsReportStatus
vacc <- usVaccines
sample <- reportSample

#Introductory/Descriptive Reports:
#1.	What proportion of public schools reported vaccination data? 
table(school$pubpriv, school$reported)
school[school$pubpriv == "PUBLIC" & school$reported == "YES",]

#2.	What proportion of private schools reported vaccination data? 
table(school$pubpriv, school$reported)

#3.	Have U.S. vaccinations rates been stable over time?
summary(vacc)
plot(vacc)
boxplot(vacc)
#create individual time series
DTP1 <- vacc[,1]
HepB_BD <- vacc[,2]
Pol3 <- vacc[,3]
Hib3 <- vacc[,4]
MCV1 <- vacc[,5]
#complete cases
cDTP1 <- na.remove(DTP1)
cHepB_BD <- na.remove(HepB_BD)
cPol3 <- na.remove(Pol3)
cHib3 <- na.remove(Hib3)
cMCV1 <- na.remove(MCV1)
#differenced, complete cases only
dDTP1 <- diff(cDTP1)
dHepB_BD <- diff(cHepB_BD)
dPol3 <- diff(cPol3)
dHib3 <- diff(cHib3)
dMCV1 <- diff(cMCV1)
#double differenced time series
ddDTP1 <- diff(dDTP1)
ddHepB_BD <- diff(dHepB_BD)
ddPol3 <- diff(dPol3)
ddHib3 <- diff(dHib3)
ddMCV1 <- diff(dMCV1)

#autocorrelation plots
acf(ddDTP1)
acf(ddHepB_BD)
acf(ddPol3)
acf(ddHib3)
acf(ddMCV1)

#df test
adf.test(ddDTP1)
adf.test(ddHepB_BD)
adf.test(ddPol3)
adf.test(ddHib3)
adf.test(ddMCV1)

#vcp double differenced
library(changepoint)
cpt.var(ddDTP1) #cp 13, 2014
plot(cpt.var(ddDTP1))
cpt.var(ddHepB_BD)
cpt.var(ddPol3) #cp 12, 1994
plot(cpt.var(ddPol3))
cpt.var(ddHib3) #cp 17, 2013
plot(cpt.var(ddHib3))
cpt.var(ddMCV1) #cp 15, 1996
plot(cpt.var(dMCV1)) #MCV1 plot

#mean cp analysis
cpt.mean(cDTP1)
cpt.mean(cHepB_BD) #cp 7, 2008
plot(cpt.mean(cHepB_BD))
cpt.mean(cPol3) #cp 15, 1994
plot(cpt.mean(cPol3))
cpt.mean(cHib3)
cpt.mean(cMCV1) #cp 7, 1986
plot(cpt.mean(cMCV1))

par(mfrow=c(3,2))
plot(cpt.var(ddDTP1), main = "DTP1")
plot(cpt.var(ddHepB_BD), main = "HepB_BD")
plot(cpt.var(ddPol3), main = "Pol3")
plot(cpt.var(ddHib3), main = "Hib3")
plot(cpt.var(ddMCV1), main = "MCV1")
#mcp plots
plot(cpt.mean(cDTP1), main = "DTP1")
plot(cpt.mean(cHepB_BD), main = "HepB_BD")
plot(cpt.mean(cPol3), main = "Pol3")
plot(cpt.mean(cHib3), main = "Hib3")
plot(cpt.mean(cMCV1), main = "MCV1")
par(mfrow=c(1,1))

#4.	Are there any notable patterns in U.S. vaccinations rates over time?

#Public vs. Private School Comparisons:
#5.	Was there any credible difference in overall reporting proportions between public and private schools?
table(school$pubpriv, school$reported)
chisq.test(table(school$pubpriv, school$reported), correct = FALSE)
library("BayesFactor")
contingencyTableBF(table(school$pubpriv, school$reported),
                   sampleType="poisson", 
                   posterior=FALSE)


#6.	Compare overall vaccination rates (allvaccs) between public and private schools. Are there any credible differences?
t.test(sample$allvaccs[sample$pubpriv=="PUBLIC"],
       sample$allvaccs[sample$pubpriv=="PRIVATE"])
library(BEST)
vaccBEST <- BESTmcmc(sample$allvaccs[sample$pubpriv=="PUBLIC"],
                     sample$allvaccs[sample$pubpriv=="PRIVATE"])
plot(vaccBEST)

#7.	Compare medical exemptions between public and private schools. Are there any credible differences?
t.test(sample$medical[sample$pubpriv=="PUBLIC"],
       sample$medical[sample$pubpriv=="PRIVATE"])
medicalBEST <- BESTmcmc(sample$medical[sample$pubpriv=="PUBLIC"],
                        sample$medical[sample$pubpriv=="PRIVATE"])
plot(medicalBEST)

#8.	Compare religious/belief exemptions between public and private schools. Are there any credible differences?
t.test(sample$religious[sample$pubpriv=="PUBLIC"],
       sample$religious[sample$pubpriv=="PRIVATE"])
religBEST <- BESTmcmc(sample$religious[sample$pubpriv=="PUBLIC"],
                        sample$religious[sample$pubpriv=="PRIVATE"])
plot(religBEST)

#Predictive Analyses:
#9.	Is it possible to predict whether a school is public or private based on conditional, medical, and religious percentages? If so, what are the specifics?
cor(sample[,c(15,6:8)])
sample$pubpriv2 <- as.numeric(sample$pubpriv) - 1 #code private=0 and public=1
sample$pubpriv3 <- 1 - sample$pubpriv2#recode public=0 and private=1
pubprivOut <- glm(formula = pubpriv3 ~ conditional + medical + religious, 
             family = binomial(), data = sample)
summary(pubprivOut)
exp(coef(pubprivOut))
exp(confint(pubprivOut))
anova(pubprivOut, test="Chisq")
library(BaylorEdPsych)
PseudoR2(pubprivOut) #Nagel 0.06
table(round(predict(pubprivOut, type="response")), sample$pubpriv) #78.6% acc, reverse diagonal
library(caret)
confusionMatrix(table(round(predict(pubprivOut, type="response")), sample$pubpriv))
library(MCMCpack)
pubprivOutb <- MCMClogit(formula = pubpriv3 ~ conditional + medical + religious, data = sample)
summary(pubprivOutb)
plot(pubprivOutb)

#10.	Is it possible to predict conditional percentage, based on the percentages of specific vaccines that are missing? If so, what are the specifics? 
condOut <- lm(conditional ~ dptMiss + polMiss + mmrMiss + hepMiss + varMiss, data = sample)
summary(condOut)
condOutBF <- lmBF(conditional ~ dptMiss + polMiss + mmrMiss + hepMiss + varMiss, data = sample)
condOutBF
condOutBF2 <- lmBF(conditional ~ dptMiss + polMiss + mmrMiss + hepMiss + varMiss, data = sample, 
                   posterior=TRUE, iterations=10000)
summary(condOutBF2)

#11.	Is it possible to predict medical percentage, based on the percentages of specific vaccines that are missing? If so, what are the specifics? 
medOut <- lm(medical ~ dptMiss + polMiss + mmrMiss + hepMiss + varMiss, data = sample)
summary(medOut)
medOutBF <- lmBF(medical ~ dptMiss + polMiss + mmrMiss + hepMiss + varMiss, data = sample)
medOutBF
medOutBF2 <- lmBF(medical ~ dptMiss + polMiss + mmrMiss + hepMiss + varMiss, data = sample, 
                   posterior=TRUE, iterations=10000)
summary(medOutBF2)

#12.	Is it possible to predict religious percentage, based on the percentages of specific vaccines that are missing? If so, what are the specifics? 
regOut <- lm(religious ~ dptMiss + polMiss + mmrMiss + hepMiss + varMiss, data = sample)
summary(regOut)
regOutBF <- lmBF(religious ~ dptMiss + polMiss + mmrMiss + hepMiss + varMiss, data = sample)
regOutBF
regOutBF2 <- lmBF(religious ~ dptMiss + polMiss + mmrMiss + hepMiss + varMiss, data = sample, 
                  posterior=TRUE, iterations=10000)
summary(regOutBF2)