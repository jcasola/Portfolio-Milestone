#' ---
#' title: "PGH Real Estate Predictions"
#' output: html_notebook
#' ---
#' 
#' ## Introduction
#' 
#' During the housing bubble of 2008, potential buyers took mortgages that they could not afford, while banks made loans that could not be repaid (Baker 2008). This helped to bring about a dramatic drop in prices that lead to one of the worst recessions in history. It is more important to be informed on more realistic housing prices to know when is the best and most appropriate time to buy.
#' 
#' Purchasing a home is one of the largest investments an individual or family will make. Knowing when prices are low is important for lower income families so they can afford their own home. Investors want to know when prices will lower and rise so they can buy houses at cheaper prices and sell them when prices rise for a profit. Investment markets, including real estate, are multi-faceted and can seem impenetrable. Besides the normal predictors of property price such as square footage and number of baths are there other possible influences on price that are not as obvious? Does the neighborhood a property is located in affect its price? Could proximity to hospitals or criminal activity help determine price?  
#' 
#' This project will explore the different aspects of neighborhoods, properties, and the city as a whole. To get a better understanding of our data, this study will look at average income of the residents, proximity to hospitals, crime, and the property values of each neighborhood in Pittsburgh, Pennsylvania.  
#' 
#' After analyzing Pittsburgh's neighborhood characteristics, data mining techniques will be used to predict the price of real estate. This study will offer insight into what variables (beds, baths, crime, etc.) affect price the most and how well real estate prices can be predicted based on those variables.  
#' 
#' ## Analysis
#' ### Data
#' 
#' Allegheny county [offers transactional records of every property sold since 2012](http://infoportal.alleghenycounty.us/resalesdata/home.aspx) (Allegheny Information Portal, 2018). This data has the price, date sold, year built, address, neighborhood, and use code --- the use code is a category which describes how the property such as "condominimum", "apartment", "duplex" or "commercial". Since the data includes all sales for Allegheny County, the data had to be paired down to zip codes inside Pittsburgh city proper.   
#' 
#' These transactions were then used to query [Zillow's API](https://www.zillow.com/howto/api/APIOverview.htm) (Zillow API, 2018) to find more information about the property. Zillow offers data on each property including, square footage and lot size as well as other typical real estate data such as number of beds, baths, and total rooms that was lacking in the original transactional dataset. Zillow's API limits queries to 1,000 per day so in order to get a sufficiently large enough dataset, the queries had to happen over several days. Any missing data (if Zillow did not return any information on a property) was then removed.
#' 
#' Having matched the property to a zip code and neighborhood offered an opportunity to import other data not typically found in real estate. The [Bureau of Labor Statistics](https://factfinder.census.gov/faces/nav/jsf/pages/index.xhtml) (Bureau of Labor Statistics, American Fact-Finder, 2018) offers median income data by zip code and the [Western Pennsylvania Regional Data Center](https://data.wprdc.org/dataset/arrest-data) (Western Pennsylvania Regional Data Center, Arrests Records, 2018) offers arrests records by neighborhood. The latitude and longitude of the property could then be used to find the closest hospital according to [Allegheny County Hospitals Data](https://catalog.data.gov/dataset/allegheny-county-hospitals) (Allegheny County Hospitals Data, 2018), using the R package "geosphere", the method "distm" and the function "distVincentyEllipsoid".
#' 
#' The data and relevant packages were loaded into the environment. The data sets were joined together and inconsistencies in the data were manually corrected. For example, in a neighborhood full of houses of around 1,500 square-feet floor-space, one house stood out at 15,000 square feet. Also, any sale prices that went for under $1,000 were removed. Having investigated many of the sub-1000-dollar real estate purchases it became clear that these were interfamily sales (husbands selling to wives, wives selling to daughters, etc.) and should not be included.  
#' 
## ----include = FALSE-----------------------------------------------------
setwd("/Users/aoliv01/Desktop/GradSchool/2018-2/DataMining/FinalProject/Final")
getwd()

#' 
## ----include = FALSE-----------------------------------------------------
#install.packages("gbm")
library(gbm)
library(httr)
library(psych)
library(tidyverse)
library(caret)
library(dplyr)
library(tools)
library(purrr)
library(lubridate)
library(ggplot2)
library(scales)
library(car)
library(gridExtra)
library(corrplot)
library(reshape)
library(sqldf)
library(geosphere)
library(utils)
library(rpart.plot)
library(randomForest)
#library(rattle)

#' 
## ----include = FALSE-----------------------------------------------------
## The next few sections are ingesting and processing datasets.
arrests_raw <- read.csv("arrests_2016.csv", stringsAsFactors = F)
zip_income_raw <- read.csv("zip_income.csv", stringsAsFactors = F)
zip_income_raw$zip <- as.factor(zip_income_raw$zip)
zip_income_raw$median_income <- as.numeric(zip_income_raw$median_income)
zip_income_raw$mean_income <- as.numeric(zip_income_raw$mean_income)

all_clean <- read.csv("all_clean.csv")
cat("\nNAs: ", sum(is.na(all_clean)))

#' 
## ----include = FALSE-----------------------------------------------------
all_clean$zip <- factor(all_clean$zip)
all_clean <- left_join(all_clean, zip_income_raw, by = "zip")
all_clean$sale_year <- sapply(all_clean$sale_date, function(x) as.factor(substr(x, 1, 4)))
all_clean$sale_month <- sapply(all_clean$sale_date, function(x) as.numeric(substr(x, 6, 7)))
cat("\nNA's: ", sum(is.na(all_clean)))

#' 
## ----include = FALSE-----------------------------------------------------
all_clean$zip <- factor(all_clean$zip)
all_clean$address <- as.character(all_clean$address)
all_clean$sale_date <- ymd(all_clean$sale_date)
all_clean$last_sold_date <- ymd(all_clean$last_sold_date)
drops <- c("X.1", "X")
all_clean <- all_clean[,!names(all_clean) %in% drops]
cat("\nNA's: ", sum(is.na(all_clean)))

#' 
## ----include = FALSE-----------------------------------------------------
temp_table <- table(arrests_raw$INCIDENTNEIGHBORHOOD)
temp_arrests <- as.data.frame(temp_table)
names(temp_arrests) <- c("neighborhood", "arrests")
temp_arrests <- temp_arrests[-1,]
all_clean <- left_join(all_clean, temp_arrests, by = c("neighborhood"))
cat("\nNA's:", sum(is.na(temp_table)))
names(temp_arrests)

#' 
## ----include = FALSE-----------------------------------------------------
## Some neighborhoods had different names in different datasets. These results were discovered through individual online searches.
all_clean[which(all_clean$neighborhood == "Southside Slopes"),]$arrests <- 272
all_clean[which(all_clean$neighborhood == "Southside Flats"),]$arrests <- 1191
all_clean[which(all_clean$neighborhood == "Herrs Island"),]$arrests <- 0
all_clean[which(all_clean$neighborhood == "Oakland"),]$arrests <- 26
all_clean[which(all_clean$neighborhood == "Shaler"),]$arrests <- 26

all_clean[which.min(all_clean$year_built),]$year_built <- 1900

all_clean <- all_clean[complete.cases(all_clean),]
cat("NA's: ", sum(is.na(all_clean)))

#' 
## ----results = "hide"----------------------------------------------------
hosp <- read.csv("pgh_hospitals.csv")

mat <- distm(all_clean[,c('lon','lat')], hosp[,c('X','Y')], fun = distVincentyEllipsoid)

near_dist <- mat[matrix(c(1:746, max.col(-mat)), ncol = 2)]
## The function returns meters which are then converted to miles. 
## This isn't a necessary step since all the distances are relative (ie 1,000 meters is further than 500 meters) but it helped in verifying the data and data munging were correct. I investigated several properties and looked each up on google for their proximity to a hospital.
all_clean$nearest_hospital <- as.numeric(format(round(near_dist / 1609.344, 2), nsmall = 2)) 

#' 
## ----echo = FALSE--------------------------------------------------------
cat("NA's: ", sum(is.na(all_clean)))

#' 
#' ### Exploratory Data Analysis and Vizualization
#' #### Price by Zip Code
#' Pittsburgh real estate prices are very skewed toward the low-end with some very high (over 1 million-dollars) homes as outliers. This skewness doesn't present itself in graph form well so the logarithm of real estate prices was used for this boxplot. 
#' 
#' 
#' This boxplot shows the variation of price by zip code. The highest priced and lowest variation is 15222. The highest variation is in zip code 15208.
#' 
## ------------------------------------------------------------------------
log_box <- ggplot(all_clean, aes(x = reorder(as.factor(zip), log(price)), y = log(price))) +
  geom_boxplot(fill = "gold", color = "black") +
  ggtitle("Log of PGH Real Estate Price by Zip Code") +
  theme(plot.title = element_text(hjust = 0.5, color = "steelblue")) + 
  scale_x_discrete(name="Zip") +
  scale_y_continuous(name="Log(Price)", label=comma) +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))
log_box

#' 
#' #### Arrests (in 2016) by Neighborhood
#' 
#' A gradual incline in arrests can be noticed from the lowest, Herr's Island --- a tiny expensive housing development in the middle of the Allegheny River --- to the third highest, Homewood South --- an impoverished neighborhood in Pittsburgh's east end. The top two, which are noticeable spikes, are the "Central Business District" and "Southside Flats." The Central Business District is downtown and has the highest population in the city during the day which explains the high number of arrests: there are more people there. Southside Flats is Pittsburgh's "drinking district". With 80 bars in a two-mile stretch, this neighborhood is prone to drunkenness, fighting and rioting after sports championship games.
#' 
## ------------------------------------------------------------------------
arrest_bar <- ggplot(all_clean, aes(reorder(neighborhood, arrests), y=arrests)) +
        geom_bar(stat='summary', fun.y = "median", fill='gold', col = "black")+
        scale_y_continuous(name = "Arrests") +
        scale_x_discrete(name = "Neighborhood") +
        theme(axis.text.x = element_text(angle = 60, hjust = 1))
arrest_bar

#' 
#' #### Price by Neighborhood and Use Code
#' 
#' Herr's Island (the tiny development with very nearly zero crime) is Pittsburgh's most expensive neighborhood. Homewood North (one of the higher-crime areas) is Pittsburgh's least expensive. This indicates that price and crime are correlated. The bar plot displaying price by use code shows that multiple-family homes, townhouses and condominiums prices that are much higher than the median. The median price of $150,000 is shown as a dotted red line.
#' 
## ------------------------------------------------------------------------
ggplot(all_clean, aes(reorder(neighborhood, -price), price)) +
        geom_bar(stat='summary', fun.y = "median", fill='black', col = "gold")+
        scale_y_continuous(breaks= seq(0, 700000, by=100000), labels = comma, name = "Price") +
        scale_x_discrete(name = "Neighborhood") +
        coord_cartesian(ylim = c(0, 700000)) +
        geom_hline(yintercept=median(all_clean$price), linetype="dashed", color = "red")   +
        theme(axis.text.x = element_text(angle = 60, hjust = 1))
ggplot(all_clean, aes(reorder(use_code, price), price)) +
        geom_bar(stat='summary', fun.y = "median", fill='black', col = "gold")+
        scale_y_continuous(breaks= seq(0, 300000, by=50000), labels = comma, name = "Price") +
        scale_x_discrete(name = "Use Code") +
        coord_cartesian(ylim = c(0, 300000)) +
        geom_hline(yintercept=median(all_clean$price), linetype="dashed", color = "red")   +
        theme(axis.text.x = element_text(angle = 60, hjust = 1))

#' 
#' 
#' #### Median Price by Sale Year and Sale Month
#' 
#' These plots explore the price by sale year and sale month. The price progresses upward from 2012, pulling out of the recession of 2008 with a small correction around 2015. And the price by month has an almost-normal curve with corrections around May and September. The median price of $150,000 is shown as a dotted red line.
#' 
## ------------------------------------------------------------------------
ys <- ggplot(all_clean, aes(x=sale_year, y=price)) +
        geom_bar(stat='summary', fun.y = "median", fill='gold', col = "black")+
        scale_y_continuous(breaks= seq(0, 800000, by=25000), labels = comma, name = "Price") +
        scale_x_discrete(name = "Sale Year") +
        coord_cartesian(ylim = c(0, 250000)) +
        geom_hline(yintercept=median(all_clean$price), linetype="dashed", color = "red")  +
        theme(axis.text.x = element_text(angle = 60, hjust = 1))

ms <- ggplot(all_clean, aes(as.numeric(sale_month), price)) +
        geom_bar(stat='summary', fun.y = "median", fill='gold', col = "black")+
        scale_y_continuous(breaks= seq(0, 800000, by=25000), labels = comma, name = "Price") +
        scale_x_continuous(breaks= seq(0, 12, by=1), labels = comma, name = "Sale Month") +
        coord_cartesian(ylim = c(0, 200000)) +
        geom_hline(yintercept=median(all_clean$price), linetype="dashed", color = "red")   +
        theme(axis.text.x = element_text(angle = 60, hjust = 1))
grid.arrange(ys, ms, widths = c(1,2))

#' 
#' #### Median Income by Neighborhood
#' 
#' The plot below shows median income for each neighborhood. There is a clear variation between median income by neighborhood. The previously mentioned Herr's Island has a substantially high median income as well as price. Morningside and Shadyside appear to have some exorbitantly priced houses compared to the median income of the neighborhood.
#' 
## ------------------------------------------------------------------------
scatterChart <- ggplot(all_clean, aes(x= reorder(neighborhood, median_income), y=median_income)) +
  ggtitle("Median Income by Neighborhood") +
  theme(plot.title = element_text(hjust = 0.5, color = "darkgray")) +
  geom_point(aes(color=price, size = price)) +
  scale_color_gradient(low="yellow", high="black") + 
  scale_y_continuous(name="Median Income", label=comma) +
  scale_x_discrete(name="Neighborhood") +
  theme(axis.text.x = element_text(angle = 60, hjust = 1))
scatterChart

#' 
#' ### Price Per Square Foot
#' 
#' Square footage appears to have a positive relationship with housing price.
## ------------------------------------------------------------------------
ggplot(all_clean, aes(x = sqft, y = price)) +
        geom_point(aes(color = price, size = sqft)) + geom_smooth(method = "lm") +
        scale_color_gradient(low="yellow", high="black") + 
        scale_y_continuous(labels = comma)

#' 
#' ### Price by Latitude and Longitude
## ------------------------------------------------------------------------
ggplot(all_clean, aes(x = lat, y = lon)) +
        geom_point(aes(color = price, size = price)) + geom_smooth(method = "lm") +
        scale_color_gradient(low="yellow", high="black") + 
        scale_y_continuous(labels = comma)

#' 
#' #### Data Skewness
#' 
#' Pittsburgh real estate tends to be less expensive, but there are also a number of houses that have a higher price. This leads the data to be very skewed. These plots explore the skewness and corrective measures such as log and square root of price.
#' 
## ------------------------------------------------------------------------
ggplot(all_clean, aes(x = price)) +
        ggtitle("Skewness of Price") +
        theme(plot.title = element_text(hjust = 0.5, color = "darkgray")) +
        geom_histogram(fill="gold", col = "black", binwidth = 10000) +
        scale_x_continuous(breaks= seq(0, 1200000, by=100000), labels = comma, name = "Price")  +
        theme(axis.text.x = element_text(angle = 60, hjust = 1))
qqnorm(all_clean$price)
qqline(all_clean$price)
qqnorm(sqrt(all_clean$price))
qqline(sqrt(all_clean$price))
ggplot(all_clean, aes(x = log(price))) +
        geom_histogram(fill="black", color = "gold", bins = 30) +
        ggtitle("Skewness of Log Price") +
        theme(plot.title = element_text(hjust = 0.5, color = "darkgray")) +
        scale_x_continuous(name = "Log of Price")  +
        theme(axis.text.x = element_text(angle = 60, hjust = 1))
ggplot(all_clean, aes(x = sqrt(price))) +
        ggtitle("Skewness of Square Root Price") +
        theme(plot.title = element_text(hjust = 0.5, color = "darkgray")) +
        geom_histogram(fill="black", color = "gold", bins = 30) +
        scale_x_continuous(name = "Square Root of Price")  +
        theme(axis.text.x = element_text(angle = 60, hjust = 1))


#' 
## ------------------------------------------------------------------------
skew(all_clean$price)
skew(sqrt(all_clean$price))
skew(log(all_clean$price))

#' 
#' The variables below were changed to the appropriate data type. Neighborhood, sale year, sale month and year built were changed into factors. A variable for the age of the house was created. It is the difference between the sale year and the year the house was built. The sale month was discretized into seasons.
#' 
## ----include = FALSE-----------------------------------------------------
all_clean$neighborhood <- factor(all_clean$neighborhood)

#' 
## ----include = FALSE-----------------------------------------------------
find_season <-  function(x) {
  y <- as.numeric(x)
  if (y <= 2) return('winter')
  if (y <= 5) return('spring')
  if (y <= 8) return('summer')
  if (y <= 10) return('fall')
  return('winter')
}
all_clean$season <- sapply(all_clean$sale_month, find_season)
all_clean$season <- as.factor(all_clean$season)

#' 
## ----include = FALSE-----------------------------------------------------
all_clean$year_built <- as.numeric(all_clean$year_built)
all_clean$sale_year <- as.numeric(as.character(all_clean$sale_year))
all_clean$age <- all_clean$sale_year - all_clean$year_built

all_clean$sale_year <- as.factor(all_clean$sale_year)
all_clean$sale_month <- as.factor(all_clean$sale_month)
all_clean$year_built <- as.factor(all_clean$year_built)

#' 
## ----include = FALSE-----------------------------------------------------
## Just some cleanup of temp sets and variables
rm(zip_income_raw)
rm(arrests_raw)
rm(hosp)
rm(temp_arrests)
rm(mat)

#' 
#' 
#' #### Preprocessing the Data
#' 
#' Since the price is so skewed it's best to normalize the data before using it in machine learning. Otherwise the characteristics of the numerous lower-priced properties will be weighted in the algorithms. The Caret package function "preProcess" with the methods of "scale and center" were used on numeric variables. These methods subtract the median value from all variables and then re-center the results around 0. So for example a price of $150,000 will go to 0, a price of $100,000 will go to -.8 and a price of $1 million will be about a 2.
#' 
## ------------------------------------------------------------------------
numeric_vars <- c("price", "tax", "lot_size", "sqft", "baths", "beds", "all_rooms", "median_income", "arrests", "nearest_hospital", "age")
factor_vars <- c("zip", "use_code", "year_built", "sale_year", "sale_month", "neighborhood", "season")
numeric_df <- all_clean[,numeric_vars]
factor_df <- all_clean[, factor_vars]
processed_nums <- preProcess(numeric_df, method=c("center", "scale"))
print(processed_nums)

#' 
## ----include = FALSE-----------------------------------------------------
norm_df <- predict(processed_nums, numeric_df)

combined <- cbind(norm_df, factor_df)

#' 
#' 
#' ##### Categorizing Prices
#' 
#' Since the kNN and SVM attempt to predict categories, the price was cut into ordinal values "low", "mid", and "high".
#' 
## ------------------------------------------------------------------------
quartiles <- summary(combined$price)
combined$price_breaks <- cut(
  combined$price,
  breaks=c(quartiles[1], quartiles[3], quartiles[5], quartiles[6]),
  labels=c("low", "mid", "high"))

#' 
## ----include = FALSE-----------------------------------------------------
cat("\nNA's introduced: ", sum(is.na(combined)))

#' 
## ----include = FALSE-----------------------------------------------------
### The price breaks we did above introduces and NA for two low price homes
combined[which(is.na(combined$price_breaks)),]$price_breaks <- "low"
cat("NA's: ", sum(is.na(combined)))

#' 
#' 
#' ##### Partitioning Data into Train and Test
#' 
#' The data was ranodmly divided into training and test sets. 70% of the data was used as the training data and 30% of the data was used as the testing data.
#' 
## ------------------------------------------------------------------------
index <- createDataPartition(combined$price_breaks, p = 0.7, list=FALSE)
train <- combined[ index,]
test <- combined[-index,]

#' 
#' 
#' ##### Cross Validation
#' 
#' 
#' Using Caret's "trainControl" method, cross-validation was set to five-fold and to be repeated 10 times using random samples.
#' 
#' 
## ------------------------------------------------------------------------
fit_control <- trainControl(method="repeatedcv", number = 5, repeats = 10)

#' 
#' ### Machine Learning Algorithms
#' #### Random Forest
#' 
#' 
#' With the "fit_control" object (cross-validation from above) various Random Forest models were created. The "tuneLength" method corresponds with the number of "mtry" for Random Forest. Mtry specifies the number of variables randomly chosen for each divide in the decision tree. Caret's train methods creates several models and tunes the model based on various input (tuneLength here) and chooses the best model based on accuracy. The plot shows accuracy based on mtry.
#' 
#' The variables chosen are continuous variables. Categorical (ordinal and nominal) variables will be used in other methods.
#' 
## ------------------------------------------------------------------------
rf_predictors <- c("lot_size", "sqft", "baths", "beds", "all_rooms", "median_income", "arrests", "nearest_hospital", "age","zip")
rf_label <- "price_breaks" 
model_rf <- train(train[,rf_predictors], train[,rf_label], method='rf', trControl = fit_control, tuneLength = 8)

#' 
## ------------------------------------------------------------------------
ggplot(model_rf$results, aes(x = mtry, y = Accuracy)) +
  geom_line(size = 2) + 
  ggtitle("Accuracy by mtry in Random Forest") +
  theme(plot.title = element_text(hjust = 0.5, color = "steelblue"))

#' 
#' #### Variable Importance by Random Forest
#' 
#' 
#' Square-footage affects price most, which reflects the theory presented earlier. Interestingly, number of bedrooms does not have an effect on price however the number of bathrooms does. Nearest hospital and arrests are also correlated to price.
#' 
## ------------------------------------------------------------------------
varImp(model_rf)

#' 
## ----include = FALSE-----------------------------------------------------
train$rf_pred_class <- predict(model_rf, train)
test$rf_pred_class <- predict(model_rf, test)

#' 
#' #### Decision Tree
#' 
## ------------------------------------------------------------------------
rf <- randomForest(price ~ lot_size + sqft + baths + all_rooms + median_income + arrests + nearest_hospital + age + zip, data = train, importance = TRUE, ntree = 800, mtry = 9, proximity = T)
varImp(rf)

#' 
#' 
#' A decision tree model was created using the train model from the Caret package.
#' 
## ------------------------------------------------------------------------
dt_predictors <- c("lot_size", "sqft", "baths","all_rooms", "median_income", "arrests", "nearest_hospital", "age", "zip")
dt_label <- "price_breaks" 
model_dt <- train(train[,dt_predictors], train[,dt_label], method='rpart', trControl = fit_control)

#' 
## ------------------------------------------------------------------------
print(model_dt)
rpart.plot(model_dt$finalModel)

#' 
## ----echo=FALSE----------------------------------------------------------
train$dt_pred_class <- predict(model_dt, train)
test$dt_pred_class <- predict(model_dt, test)

#' 
#' 
#' #### Naïve Bayes
#' 
#' Using Caret's "train" method and the "fit_control" (cross-validation from above) using the same cross-validation ("trainControl") from above, several Naïve Bayes models were created. The "tuneLength" which corresponded to mtry in Random Forest is not applicable for NB.
#' 
#' The variables chosen are categorical (ordinal and nominal) variables.
#' 
## ------------------------------------------------------------------------
set.seed(5676)
nb_label <- "price_breaks"
nb_predictors <- c("zip", "use_code", "year_built", "sale_year", "sale_month", "neighborhood", "season")
nb_grid = expand.grid(usekernel = c(TRUE, FALSE), fL = 0:5, adjust = 5)
model_nb <- train(train[, nb_predictors], train[, nb_label], method='nb', trControl = fit_control, tuneGrid = nb_grid)

#' 
## ------------------------------------------------------------------------
plot(model_nb)

#' 
#' 
#' 
## ----include = FALSE-----------------------------------------------------
## Run if an NA got introduced
#train <- train[complete.cases(train),]
cat("\nNA's in train: ", sum(is.na(train)))
cat("\nNA's in test: ", sum(is.na(test)))

#' 
## ----include = FALSE-----------------------------------------------------
train$nb_pred <- predict(model_nb, train)
test$nb_pred <- predict(model_nb, test)


#' 
#' 
#' #### Support Vector Machines
#' 
#' 
#' Using a new "fit_control" (cross-validation) with class probabilities allows the SVM algorithm to predict categorical variables. Also, an "expand.grid" object is created to vary "sigma" and "C" parameters throughout the cross-validation process. As SVM uses numerical variables, the Random Forest predictors can be re-used.
#' 
#' 
#' The plot shows the accuracy of each sigma and C parameter used throughout cross-validation.
#' 
#' 
## ------------------------------------------------------------------------
svm_grid <- expand.grid(C = c(0.05, 0.1, 0.25, 0.5, 1, 1.5, 2, 5), sigma = c(.01, .02, .03, .04, .05, .06, .07, .08, .09, .1, .25, .5, .75, .9))
svm_fit_control <- trainControl(method="repeatedcv", number = 3, repeats = 5, classProbs = T)
svm_predictors <- c("lot_size", "sqft", "baths", "beds", "all_rooms", "median_income", "arrests", "nearest_hospital", "age")
svm_label <- "price_breaks"
model_svm <- train(train[,svm_predictors], train[,svm_label], method='svmRadial', trControl = svm_fit_control, tuneGrid = svm_grid)

#' 
## ------------------------------------------------------------------------
plot(model_svm)

#' 
#' 
## ----include = FALSE-----------------------------------------------------
train$svm_pred <- predict(model_svm, train[, svm_predictors])
test$svm_pred <- predict(model_svm, test[, svm_predictors])

#' 
#' 
## ----include = FALSE-----------------------------------------------------
## Run if an NA got introduced
#train <- train[complete.cases(train),]
cat("\nNA's in train: ", sum(is.na(train)))
cat("\nNA's in test: ", sum(is.na(test)))

#' 
#' #### k Nearest Neighbor :: Ensemble Boosting
#' 
#' 
#' Using the previous algorithms predictions, a kNN model was trained. To process the ordinal variable ("low", "mid", and "high") predictions into numerical, the "model.matrix" method was used to "one-hot encode" each prediction. This method creates a matrix of dummy variables with a binary value -- 1 or 0. We'll also use the continuous variables for square-footage, baths, median income, arrests, and nearest hospitals --- previously found to be important by other models. 
#' 
#' The "fit_control" parameter runs kNN through various cross-validation cycles. The plot below shows the accuracy as different neighbor centroids are used.
#' 
#' 
## ------------------------------------------------------------------------
preds_all <- c("rf_pred_class", "nb_pred", "svm_pred")
dum_df <- as.data.frame(model.matrix(~.-1, train[,preds_all]))
train <- cbind(train, dum_df)
dum_df <- as.data.frame(model.matrix(~.-1, test[,preds_all]))
test <- cbind(test, dum_df)

preds_binary <- names(dum_df)

knn_predictors <- c(preds_binary, "sqft", "baths", "median_income", "arrests", "tax", "nearest_hospital")
knn_label <- "price_breaks"

model_knn <- train(train[,knn_predictors], train[,knn_label], method='knn', trControl = fit_control)

#' 
## ------------------------------------------------------------------------
plot(model_knn)

#' 
## ----echo = FALSE--------------------------------------------------------
train$knn_pred <- predict(model_knn, train[, knn_predictors])
test$knn_pred <- predict(model_knn, test[, knn_predictors])

#' 
#' ### Results
#' #### With Training Data
#' 
#' The accuracy of the Random Forest model, which is over 99%, suggests that this model is overfitted to the training data. The kNN model is overfitted to the training data as well, possibly because it uses the same predictors as the Random Forest model.
#' 
## ----echo = FALSE--------------------------------------------------------
cat("\nSVM Model in train:\n")
confusionMatrix(train$svm_pred, train$price_breaks)$overall['Accuracy']

cat("\nDecision Tree Model in train:\n")
confusionMatrix(train$dt_pred_class, train$price_breaks)$overall['Accuracy']

cat("\nRandom Forest Model in train:\n")
confusionMatrix(train$rf_pred_class, train$price_breaks)$overall['Accuracy']

cat("\nNB Model in train:\n")
confusionMatrix(train$nb_pred, train$price_breaks)$overall['Accuracy']

cat("\nkNN Model in train:\n")
confusionMatrix(train$knn_pred, train$price_breaks)$overall['Accuracy']

#' 
#' 
#' #### With Testing Data
#' 
#' The results of running the model against testing data shows that the Random Forest model, and by extension the kNN model, were overfit. However, the accuracy of kNN ensemble is increased over the accuracy of the models used to build it. This shows that boosting the models, using previous predictions, gives a slight advantage.
#' 
#' 
## ----echo = FALSE--------------------------------------------------------
cat("SVM Model in test:\n")
confusionMatrix(test$svm_pred, test$price_breaks)$overall['Accuracy']

cat("\nDecision Tree Model in test:\n")
confusionMatrix(test$dt_pred_class, test$price_breaks)$overall['Accuracy']

cat("\nRandom Forest Model in test:\n")
confusionMatrix(test$rf_pred_class, test$price_breaks)$overall['Accuracy']

cat("\nNaive Bayes Model in test:\n")
confusionMatrix(test$nb_pred, test$price_breaks)$overall['Accuracy']

cat("\nkNN Model in test:\n")
confusionMatrix(test$knn_pred, test$price_breaks)$overall['Accuracy']

#'   
#'   
#'   
#' #### kNN Ensemble Model Confusion Matrix
#' 
#' 
#' The models mixed together the low and mid-priced homes. This is understandable considering the variation in prices per zip code from the first graph. There is considerable overlap between areas, meaning mid-range neighborhoods probably had mid-range houses with similar characteristics to low-priced homes.
#' 
#' 
#' To address this, a characteristic such as "condition" of the property --- "rundown", "renovated", "brand new", etc. --- would have to be found and incorporated. This ordinal variable would give distinction between similar homes with similar characterstics (but which have dissimilar value) and would further expand the gap between the mid and low ranges. 
#' 
## ------------------------------------------------------------------------
confusionMatrix(test$knn_pred, test$price_breaks)['table']

#' 
#' ### Conclusion
#' 
#' 
#' The results of each model show that predicting real estate price is possible with data mining techniques. Also, unorthodox variables outside the scope of property characteristics such as median income, arrests, and proximity to hospitals affect property value. This is an intuitive result which is typically not included in property valuation.
#' 
#' Further study could be done by incorporating a "condition" variable for each property. Data concerning arrests can also be normalized further by creating an index of arrests per capita: the large outlier of downtown could be mitigated by transforming arrests into a percentage by population. 
#' 
#' The Random Forest model and kNN also overfit the training data even with cross-validation. This may happen because the original dataset contains only 746 observations, a result of Zillow's API daily limit and NA values introduced. Re-running the Zillow API calls with the daily cap lifted (to get upwards of 20,000 results paired with the original Allegheny transactions data) might abate the overfitting.
#' 
#' ### References
#' 
#' Allegheny Information Portal, 2018. [online] Available at: [http://infoportal.alleghenycounty.us/resalesdata/home.aspx](http://infoportal.alleghenycounty.us/resalesdata/home.aspx), [Accessed 15 May, 2018]
#' 
#' Allegheny County Hospitals Data, 2018. [online] Available at: [https://catalog.data.gov/dataset/allegheny-county-hospitals](https://catalog.data.gov/dataset/allegheny-county-hospitals), [Accessed 15 May, 2018]
#' 
#' Baker, Dean, PBS, 2008. [online] Available at [http://www.pbs.org/now/shows/412/housing-recession.html] (http://www.pbs.org/now/shows/412/housing-recession.html), [Accessed 15, June 2018]
#' 
#' Bureau of Labor Statistics, American Fact-Finder, 2018. [online] Available at: [https://factfinder.census.gov/faces/nav/jsf/pages/index.xhtml](https://factfinder.census.gov/faces/nav/jsf/pages/index.xhtml), [Accessed 15 May, 2018]
#' 
#' Western Pennsylvania Regional Data Center, Arrests Records, 2018. [online] Available at: [https://data.wprdc.org/dataset/arrest-data](https://data.wprdc.org/dataset/arrest-data), 2018
#' 
#' Zillow API, 2018. [online] Available at: [https://www.zillow.com/howto/api/APIOverview.htm](https://www.zillow.com/howto/api/APIOverview.htm), [Accessed 15 May, 2018]
#' 
#' 
#' 
#' 
#' 
#' 
#' 
#' 
#' 
#' 
