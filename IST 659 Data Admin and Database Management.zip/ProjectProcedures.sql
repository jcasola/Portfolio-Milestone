--template from Lab8 q10
CREATE PROCEDURE AddProduct(@name char(30), @description varchar(255)) AS
BEGIN
	DECLARE @ProductCount int
	SELECT @ProductCount = COUNT(ProductID) FROM Product
		WHERE ProductName = @name
	IF @ProductCount = 0
	BEGIN
		INSERT INTO Product (ProductName, ProductDescription)
		VALUES (@name, @description)
	END
	RETURN @@IDENTITY
END

--Lab7 q3
-- have an input be @companyname and @exhibitionname 
INSERT INTO VendorProduct (Cost, ProductID, VendorID)
VALUES (50,(SELECT ProductID
FROM Product WHERE ProductName = 'Red Shoes'),(SELECT VendorID
FROM Vendor WHERE VendorName = 'Spikey'))

INSERT INTO Contract (Cost, ProductID, VendorID)
VALUES (50
	, (SELECT ProductID FROM Product WHERE CompanyName = @CompanyName)
	, (SELECT VendorID FROM Vendor WHERE ExhibitionName = @ExhibitionName)
	)

--template from Lab8 q13
CREATE PROCEDURE AddProduct(@name char(30), @description varchar(255)) AS
BEGIN
	DECLARE @ProductCount int
	SELECT @ProductCount = COUNT(ProductID) FROM Product
		WHERE ProductName = @name
	IF @ProductCount = 0
	BEGIN
		INSERT INTO Product (ProductName, ProductDescription)
		VALUES (@name, @description)
	END
	RETURN @@IDENTITY
END

CREATE PROCEDURE AddContract(@TotalContractValue decimal(10,2)
	, @Discount decimal(10,2)
	, @NetContractValue decimal(10,2)
	, @AmountPaid decimal(10,2)
	, @RemainingBalance decimal(10,2)
	, @PaymentDueDate datetime)
BEGIN
	DECLARE @ProductCount int
	SELECT @ProductCount = COUNT(ProductID) FROM Product
		WHERE ProductName = @name
	IF @ProductCount = 0
	BEGIN
		IF 
			INSERT INTO Contract (TotalContractValue, Discount, NetContractValue, AmountPaid, RemainingBalance, PaymentDueDate)
			VALUES (@name, @description)
	END
	RETURN @@IDENTITY
END

--easy
CREATE PROCEDURE AddContract(@ContractValue decimal(10,2)
	, @AmountPaid decimal(10,2)
	, @RemainingBalance decimal(10,2)
	, @PaymentDueDate datetime)
BEGIN
	DECLARE @ProductCount int
	SELECT @ProductCount = COUNT(ProductID) FROM Product
		WHERE ProductName = @name
	IF @ProductCount = 0
	BEGIN
		IF 
			INSERT INTO Contract (TotalContractValue, Discount, NetContractValue, AmountPaid, RemainingBalance, PaymentDueDate)
			VALUES (@name, @description)
	END
	RETURN @@IDENTITY
END

--no procedure
INSERT INTO Contract (TotalContractValue, Discount, NetContractValue, AmountPaid, RemainingBalance, PaymentDueDate, CompanyID, ExhibitionID)
VALUES (200000.00, 4530.00, (TotalContractValue-Discount), 1000.00, (NetContractValue - AmountPaid), 1/23/2018, 0045, 0054)

--test
CREATE TABLE ContractTest (
	ContractID int identity primary key not null
	, TotalContractValue decimal(10,2) not null
	, Discount decimal(10,2) default 0
	, NetContractValue decimal(10,2) not null
	, AmountPaid decimal(10,2) default 0
	, RemainingBalance decimal(10,2) not null
	, PaymentDueDate datetime not null
)

--doesn't work
INSERT INTO ContractTest (TotalContractValue, Discount, NetContractValue, AmountPaid, RemainingBalance, PaymentDueDate)
VALUES (200000.00, 4530.00, (TotalContractValue-Discount), 1000.00, (NetContractValue - AmountPaid), 1/23/2018)

--works
INSERT INTO ContractTest (TotalContractValue, Discount, NetContractValue, AmountPaid, RemainingBalance, PaymentDueDate)
VALUES (200000.00, 4530.00, (200000.00 - 4530.00), 1000.00, ((200000.00 - 4530.00) - 1000), 2018-01-23)

INSERT INTO ContractTest (TotalContractValue, Discount, NetContractValue, AmountPaid, RemainingBalance, PaymentDueDate)
VALUES (200000.00, 0, (200000.00 - 0), 0, ((200000.00 - 0) - 0), 01-23-2018)

SELECT * FROM ContractTest

DROP TABLE ContractTest