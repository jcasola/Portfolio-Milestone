IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'Address')
BEGIN
	DROP TABLE Address
END
GO;

--This block of code creates the Address table. It contains the attributes Address, City, StateAbb and PostalCode.
CREATE TABLE Address (
	AddressID int identity primary key not null	
    , Address varchar(100) not null
	, City varchar(100) not null
	, State char(2) not null
	, PostalCode  varchar(16) not null
);

DROP TABLE Address;

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'Company')
BEGIN
	DROP TABLE Company
END
GO;

--This block of code creates the Company table. It contains the attributes CompanyID, CompanyName, CompanyAddress and CompanyPhoneNumber
CREATE TABLE Company (
	CompanyID int identity primary key not null
	, CompanyName varchar(50) not null
	, CompanyPhoneNumber char(10) not null
	, AddressID int foreign key references Address(AddressID) not null
);

DROP TABLE Company;

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'Venue')
BEGIN
	DROP TABLE Venue
END
GO;

--This block of code creates the Venue table. It contains the attributes VenueID, VenueName, VenueAddress, VenuePhoneNumber as columns with AddressID as a foreign key.
CREATE TABLE Venue (
	VenueID int identity primary key not null
	, VenueName varchar(50) not null
	, VenuePhoneNumber char(10) not null
	, AddressID int foreign key references Address(AddressID) not null
);

DROP TABLE Venue;

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'Exhibition')
BEGIN
	DROP TABLE Exhibition
END
GO;

--This block of code creates the Exhibition table. It contains the attributes CompanyID, CompanyName, CompanyAddress, CompanyPhoneNumber as columns  with AddressID as a foreign key.
CREATE TABLE Exhibition (
	ExhibitionID int identity primary key not null
	, ExhibitionName varchar(50) not null
	, ExhibitionDateTime datetime not null
	, VenueID int foreign key references Venue(VenueID) not null
);

DROP TABLE Exhibition;

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'Booth')
BEGIN
	DROP TABLE Booth
END
GO;

--This block of code creates the Booth table. It contains the attributes BoothID, BoothNumber as columns with CompanyID and ExhibitionID as foreign keys
CREATE TABLE Booth (
	BoothID int identity primary key not null
	, BoothNumber varchar(4) not null
	, CompanyID int foreign key references Company(CompanyID) not null
	, ExhibitionID int foreign key references Exhibition(ExhibitionID) not null
);

DROP TABLE Booth;

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'Contract')
BEGIN
	DROP TABLE Contract
END
GO;

--This block of code creates the Contract table. It contains the attributes ContractID, ContractValue, Paid, PaymentDueDate as columns with CompanyID and ExhibitionID as foreign keys
CREATE TABLE Contract (
	ContractID int identity primary key not null
	, ContractValue decimal(10,2) not null
	, Paid char(6) default 'Unpaid'
	, PaymentDueDate datetime not null
	, CompanyID int foreign key references Company(CompanyID) not null
	, ExhibitionID int foreign key references Exhibition(ExhibitionID) not null
);

--old contract
CREATE TABLE Contract (
	ContractID int identity primary key not null
	, TotalContractValue decimal(10,2) not null
	, Discount decimal(10,2) default 0
	, NetContractValue decimal(10,2) not null
	, AmountPaid decimal(10,2) default 0
	, RemainingBalance decimal(10,2) not null
	, PaymentDueDate datetime not null
	, CompanyID int foreign key references Company(CompanyID) not null
	, ExhibitionID int foreign key references Exhibition(ExhibitionID) not null
);

--this code drops the contract table
DROP TABLE Contract