--insert templates
INSERT INTO Address(Address, City, State, PostalCode)
VALUES (

INSERT INTO Company(CompanyName, CompanyPhoneNumber, AddressID)
VALUES (

INSERT INTO Venue(VenueName, VenuePhoneNumber, AddressID)
VALUES (

INSERT INTO Exhibition(ExhibitionName, ExhibitionDateTime, VenueID)
VALUES (

INSERT INTO Booth(BoothNumber, CompanyID, ExhibitionID)
VALUES (

INSERT INTO Contract(ContractValue,PaymentDueDate,CompanyID,ExhibitionID)
VALUES (

INSERT INTO Contract(ContractValue,Paid,PaymentDueDate,CompanyID,ExhibitionID)
VALUES (

--address inserts for companies
INSERT INTO Address(Address, City, State, PostalCode)
VALUES ('100 Maple St', 'Trumbull', 'CT', '10000')
INSERT INTO Address(Address, City, State, PostalCode)
VALUES ('200 Elm St', 'New York', 'NY', '20000')
INSERT INTO Address(Address, City, State, PostalCode)
VALUES ('300 Main St', 'Greenbough','AL', '30000')
INSERT INTO Address(Address, City, State, PostalCode)
VALUES ('400 West St','Miami','FL','40000')
INSERT INTO Address(Address, City, State, PostalCode)
VALUES ('500 East Rd','San Francisco','CA','50000')
--address inserts for venues
INSERT INTO Address(Address, City, State, PostalCode)
VALUES ('600 College Rd','Philadelphia','PA','60000')
INSERT INTO Address(Address, City, State, PostalCode)
VALUES ('700 Birch St','Boston','MA','70000')
INSERT INTO Address(Address, City, State, PostalCode)
VALUES ('800 Spring St','Houston','TX','80000')
INSERT INTO Address(Address, City, State, PostalCode)
VALUES ('900 Garfield Ave','Seattle','WA','90000')
INSERT INTO Address(Address, City, State, PostalCode)
VALUES ('1000','Portland','ME','99900')

--change address to an actual address. The address field was previously '1000'.
UPDATE Address SET Address.Address = '1000 Lambert Dr' WHERE Address.AddressID = 10

--company inserts
INSERT INTO Company(CompanyName, CompanyPhoneNumber, AddressID)
VALUES ('Data Science Inc','1-111-1111',1)
INSERT INTO Company(CompanyName, CompanyPhoneNumber, AddressID)
VALUES ('Database Fun Co','2-222-2222',2)
INSERT INTO Company(CompanyName, CompanyPhoneNumber, AddressID)
VALUES ('Good Grade Inc','3-333-3333',3)
INSERT INTO Company(CompanyName, CompanyPhoneNumber, AddressID)
VALUES ('SQL Champs Inc','4-444-4444',4)
INSERT INTO Company(CompanyName, CompanyPhoneNumber, AddressID)
VALUES ('Creative Names Co','5-555-5555',5)

--venue inserts
INSERT INTO Venue(VenueName, VenuePhoneNumber, AddressID)
VALUES ('Venue A','6-666-6666',6)
INSERT INTO Venue(VenueName, VenuePhoneNumber, AddressID)
VALUES ('Venue B','7-777-7777',7)
INSERT INTO Venue(VenueName, VenuePhoneNumber, AddressID)
VALUES ('Venue C','8-888-8888',8)
INSERT INTO Venue(VenueName, VenuePhoneNumber, AddressID)
VALUES ('Venue D','9-999-9999',9)
INSERT INTO Venue(VenueName, VenuePhoneNumber, AddressID)
VALUES ('Venue E','1-234-5678',10)

--exhibition inserts
INSERT INTO Exhibition(ExhibitionName, ExhibitionDateTime, VenueID)
VALUES ('SQL Con','2017-01-01 01:00:00 PM',1)
INSERT INTO Exhibition(ExhibitionName, ExhibitionDateTime, VenueID)
VALUES ('Car Con','2017-02-02 02:00:00 PM',2)
INSERT INTO Exhibition(ExhibitionName, ExhibitionDateTime, VenueID)
VALUES ('Golf Con','20170303 03:00:00 PM',3)
INSERT INTO Exhibition(ExhibitionName, ExhibitionDateTime, VenueID)
VALUES ('Data Science Con','2017-04-04 04:00:00 PM',4)
INSERT INTO Exhibition(ExhibitionName, ExhibitionDateTime, VenueID)
VALUES ('Sports Con','2017-05-05 05:00:00 PM',5)

--booth inserts
INSERT INTO Booth(BoothNumber, CompanyID, ExhibitionID)
VALUES ('101',1,1)
INSERT INTO Booth(BoothNumber, CompanyID, ExhibitionID)
VALUES ('202',2,2)
INSERT INTO Booth(BoothNumber, CompanyID, ExhibitionID)
VALUES ('303',3,3)
INSERT INTO Booth(BoothNumber, CompanyID, ExhibitionID)
VALUES ('404',4,4)
INSERT INTO Booth(BoothNumber, CompanyID, ExhibitionID)
VALUES ('505',5,5)

--contract inserts with default
INSERT INTO Contract(ContractValue,PaymentDueDate,CompanyID,ExhibitionID)
VALUES (100000,'2018-01-01',1,1)
INSERT INTO Contract(ContractValue,PaymentDueDate,CompanyID,ExhibitionID)
VALUES (200000,'2018-02-02',2,2)
INSERT INTO Contract(ContractValue,PaymentDueDate,CompanyID,ExhibitionID)
VALUES (300000,'2018-03-03',3,3)
INSERT INTO Contract(ContractValue,PaymentDueDate,CompanyID,ExhibitionID)
VALUES (400000,'2018-04-04',4,4)

--contract insert no default
INSERT INTO Contract(ContractValue,Paid,PaymentDueDate,CompanyID,ExhibitionID)
VALUES (500000,'Paid','2018-05-05',5,5)

--add the date a row is added into the contract table.
ALTER TABLE Contract
ADD ContractDateAdded datetime
DEFAULT GETDATE () 

--find current revenue
SELECT SUM(ContractValue) AS Revenue
	, ContractValue
	, Paid
	, CompanyName
	, ExhibitionName
	, BoothNumber
FROM Contract
JOIN Company ON Contract.CompanyID = Company.CompanyID
JOIN Exhibition ON Contract.ExhibitionID = Exhibition.ExhibitionID
JOIN Booth ON Exhibition.ExhibitionID = Booth.ExhibitionID
WHERE Paid = 'Paid'
GROUP BY ContractValue, Paid, CompanyName, ExhibitionName, BoothNumber

--find unpaid contracts
SELECT Paid 
	, PaymentDueDate
	, ContractValue
	, CompanyName
	, ExhibitionName
	, BoothNumber
FROM Contract
JOIN Company ON Contract.CompanyID = Company.CompanyID
JOIN Exhibition ON Contract.ExhibitionID = Exhibition.ExhibitionID
JOIN Booth ON Exhibition.ExhibitionID = Booth.ExhibitionID
WHERE Paid = 'Unpaid' AND PaymentDueDate < Getdate()



--code to add the date the contract information was added to the contract table
ALTER TABLE Contract
ADD ContractDateAdded datetime default GETDATE()

--code to add the date the contract information was added to the contract table
ALTER TABLE Contract
ADD ContractDateAdded datetime default GETDATE()

--the following code deletes data from columns in the tables
DELETE FROM Company WHERE CompanyName = 'Good Grade Inc'

--the following 
DELETE FROM Contract WHERE COUNT(ContractID=1) > 1